const infobip = () => {
  
  const MySecretAuth = {
    tracksend_user: "thinktech",
    tracksend_pwrd: "Tjflash8319#",
    tracksend_base_url: "jj8wk.api.infobip.com",
  };
    //sk_test_xxxx to be replaced by your own secret key
  
  return MySecretAuth;
}

module.exports = infobip;