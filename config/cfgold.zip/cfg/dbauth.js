const dbauth = () => {
  
  const DBAuth = {
    dbuser: "ts_user",
    dbpwrd: "ts_pwrd",
    dbdb: "tracksend",
  };
    //sk_test_xxxx to be replaced by your own secret key
  
  return DBAuth;
}

module.exports = dbauth;