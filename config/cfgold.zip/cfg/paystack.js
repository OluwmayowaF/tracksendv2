const paystack = () => {
  
  const MySecretKey = 'Bearer sk_test_xxxx';
  //sk_test_xxxx to be replaced by your own secret key
  
  return MySecretKey;
}

module.exports = paystack;